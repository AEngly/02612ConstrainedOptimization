function varargout = temporary_file(varargin)
    %TEMPORARY_FILE [INTERNAL] 
    %
    %  char = TEMPORARY_FILE(char prefix, char suffix)
    %
    %
  [varargout{1:nargout}] = casadiMEX(37, varargin{:});
end
