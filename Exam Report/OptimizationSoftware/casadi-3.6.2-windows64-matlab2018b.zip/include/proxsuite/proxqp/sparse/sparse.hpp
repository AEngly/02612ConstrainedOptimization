//
// Copyright (c) 2022 INRIA
//
/** \file */
#ifndef PROXSUITE_PROXQP_SPARSE_SPARSE_HPP
#define PROXSUITE_PROXQP_SPARSE_SPARSE_HPP

#include "proxsuite/proxqp/sparse/wrapper.hpp" // includes everything

#endif /* end of include guard PROXSUITE_PROXQP_SPARSE_SPARSE_HPP */
