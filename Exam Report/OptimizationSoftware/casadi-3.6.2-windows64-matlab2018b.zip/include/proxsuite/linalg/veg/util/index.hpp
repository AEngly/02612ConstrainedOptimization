#ifndef VEG_INDEX_HPP_UX3WGF18S
#define VEG_INDEX_HPP_UX3WGF18S

#include "proxsuite/linalg/veg/internal/dyn_index.hpp"

#endif /* end of include guard VEG_INDEX_HPP_UX3WGF18S */
