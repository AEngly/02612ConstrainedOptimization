function varargout = convexify(varargin)
    %CONVEXIFY 
    %
    %  MX = CONVEXIFY(MX H, struct opts)
    %
    %
  [varargout{1:nargout}] = casadiMEX(901, varargin{:});
end
